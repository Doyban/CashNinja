var CashNinja = CashNinja || {};

CashNinja.Upgrade = function (game_state) {
  "use strict";
  this.game_state = game_state; // Save game state.
};

CashNinja.Upgrade.prototype.apply = function () {
  "use strict";
};